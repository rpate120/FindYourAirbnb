class ResultsController < ApplicationController

  def index

  end
end