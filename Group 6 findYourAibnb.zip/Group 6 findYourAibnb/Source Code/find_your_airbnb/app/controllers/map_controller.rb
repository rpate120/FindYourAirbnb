class MapController < ApplicationController

  def results
  
  
    city_name = params[ :city_name ].to_s
    target_price = params[ :target_price ].to_f
    accomodates = params[ :accomodates ].to_f
    bedrooms = params[ :bedrooms ].to_f



    airbnbs = Airbnb.where( "city = ?", city_name ).
                   where( "price <= ?" ,target_price ).
                   where( "accommodates <= ?", accomodates ).
                   where( "bedrooms <= ?", bedrooms )
                  # where( "instant_bookable <= ?", accomodates ).
                  # where( "host_since <= ?", hosted_since )
    
    @airbnbs = airbnbs


  end

  def index

  end
end