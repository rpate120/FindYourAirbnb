class QuizController < ApplicationController

  def new
  end

  def index
    # 0 = cost_of_living, 1 = transportation, 2 = vegan_options, 3 = landmarks_hiking, 4 = shopping_mall, 5 = live_music, 6 = food
    baseline = { cost_of_living: 159, transportation: 2, vegan_options: 150,
                 landmarks_hiking: 2, shopping_mall: 2, live_music: 2, food: 2 }

    trip_type = params[ :trip_type ].to_f
    target_price = params[ :target_price ].to_f
    travel_distance = params[ :travel_distance ].to_f
    travel_type = params[ :travel_type ].to_f
    city_rural = params[ :city_rural ].to_f
    scenery = params[ :scenery ].to_f
    foodie = params[ :foodie ].to_f
    food_type = params[ :food_type ].to_f
    bars = params[ :bars ].to_f
    meseums = params[ :meseums ].to_f
    parks = params[ :parks ].to_f
    shopping = params[ :shopping ].to_f
    live_music = params[ :live_music].to_f
    perfect_weekend = params[ :perfect_weekend ].to_f

    # aggregate weights
    transport = city_rural
    food_type == 1.5 ? vegan = 50 : vegan = -50
    landmark = scenery + meseums + parks
    shop = shopping
    music = live_music
    food = foodie + bars

    # +1 depending on answer for last question
    landmark - 2 if perfect_weekend == 1
    food + 2 if perfect_weekend == 2
    live_music + 2 if perfect_weekend == 3
    landmark + 2 if perfect_weekend == 4
    shopping + 2 if perfect_weekend == 5
    # +/- baseline
    baseline[ :transportation ] = baseline[ :transportation ]
    baseline[ :vegan_options ] = baseline[ :vegan_options ] + vegan
    baseline[ :landmarks_hiking ] = baseline[ :landmarks_hiking ] + landmark 
    baseline[ :shopping_mall ] = baseline[ :shopping_mall ] + shop
    baseline[ :live_music ] = baseline[ :live_music ] + music
    baseline[ :food ] = baseline[ :food ] + food

    @transport = baseline[ :transportation ]
    @vegan = baseline[ :vegan_options ]
    @landmark = baseline[ :landmarks_hiking ]
    @shop = baseline[ :shopping_mall ]
    @music = baseline[ :live_music ]
    @food = baseline[ :food ]

    # indexing starts at -3 because cost_of_living and vegan_options will always be -1 and -2
    first_key = baseline.key baseline.values.sort[ -3 ]
    second_key = baseline.key baseline.values.sort[ -4 ]
    third_key = baseline.key baseline.values.sort[ -5 ]



    f3 = City.order( "#{first_key.to_s} DESC" ).limit( 3 )
    # p first_key
    # f5.each{ |x| p x.name
    #              p x.public_send( first_key.to_s )}
    #
    f3 = f3.sort_by { |obj| obj.public_send( second_key.to_s ) }.reverse
    # p second_key
    # f3.each{ |x| p x.name
    #              p x.public_send( second_key.to_s )}

    f1 = f3[0..-2]
    f1 = f1.sort_by { |obj| obj.public_send( third_key.to_s ) }.reverse
    # p third_key
    # f1.each{ |x| p x.name
    #              p x.public_send( third_key.to_s )}

    city = f1.first
    @city = city

      airbnbs = Airbnb.where( "city = ?", city.name ).
                       where( "price <= ?" ,target_price )
                        # where( "instant_bookable <= ?", accomodates ).
                        # where( "host_since <= ?", hosted_since )
        p '*****************'
        p airbnbs.count
        p '*****************'
        @airbnbs = airbnbs[0 .. 4]


    # objects.sort_by {|obj| obj.attribute}
    # city = City.maximum("#{first_key.to_s}")
                # where( "landmarks_hiking > ?", baseline[ :landmarks_hiking ] ).
                # where( "shopping_mall > ?", baseline[ :shopping_mall ] ).
                # where( "food > ?", baseline[ :food ] )

  end


  def show
  end
end
