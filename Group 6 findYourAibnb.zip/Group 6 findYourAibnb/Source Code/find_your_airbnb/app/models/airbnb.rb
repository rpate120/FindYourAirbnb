class Airbnb < ApplicationRecord


end