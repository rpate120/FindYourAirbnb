class City < ApplicationRecord

  has_many :Airbnbs


end