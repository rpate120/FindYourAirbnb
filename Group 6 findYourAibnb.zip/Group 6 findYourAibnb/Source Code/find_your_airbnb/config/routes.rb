Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  get 'home/', to: 'home#index', as: 'home'
  get 'quiz/new', to: 'quiz#new', as: 'quiz'
  get 'map/', to: 'map#index', as: 'map'
  get 'map/fuck', to: 'map#fuck', as: 'map_fuck'
  get 'map/results', to: 'map#results', as: 'map_results'
  get 'quiz/results', to: 'quiz#index', as: 'results'
  get 'quiz/show', to: 'quiz#show', as: 'show'


  root 'home#index'

end
