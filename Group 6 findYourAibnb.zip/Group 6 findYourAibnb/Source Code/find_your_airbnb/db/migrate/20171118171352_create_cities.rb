class CreateCities < ActiveRecord::Migration[5.1]
  def change
    create_table :cities do |t|
      t.string "name"
      t.string "state"
      t.text "description"
      t.string "features"
      t.float "cost_of_living"
      t.integer "transportation"
      t.integer "vegan_options"
      t.integer "landmarks_hiking"
      t.integer "shopping_mall"
      t.integer "live_music"
      t.integer "food"
    end
  end
end
