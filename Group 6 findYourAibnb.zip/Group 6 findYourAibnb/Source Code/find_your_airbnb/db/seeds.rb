# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


require 'csv'

# csv_text = File.read(Rails.root.join('lib', 'seeds', 'cities_final.csv'))
# csv = CSV.parse(csv_text.scrub, :headers => true)
# csv.each do |row|
#   c = City.new
#   c.id = row['id']
#   c.name = row['city']
#   c.state = row['state']
#   c.description = row['description']
#   c.features = row['features']
#   c.cost_of_living = row['cost_of_living']
#   c.transportation = row['transportation']
#   c.vegan_options = row['vegan_option']
#   c.landmarks_hiking = row['landmark_hiking']
#   c.shopping_mall = row['shopping_malls']
#   c.live_music = row['live_music']
#   c.food = row['food']
#   c.save
#   puts "Saving #{c.name}"
# end


# csv_text = File.read(Rails.root.join('lib', 'seeds', 'airbnbs_final.csv'))
# csv = CSV.parse(csv_text.scrub, :headers => true)
# csv.each do |row|
#   a = Airbnb.new

#   a.id = row[ 'id' ]
#   a.airbnb_id = row[ 'airbnb_id' ]
#   a.name = row[ 'name' ]
#   a.summary = row[ 'summary' ]
#   a.space = row[ 'space' ]
#   a.description = row[ 'description' ]
#   a.house_rules = row[ 'house_rules' ]
#   a.picture_url = row[ 'picture_url' ]
#   a.host_id = row[ 'host_id' ]
#   a.host_name = row[ 'host_name' ]
#   a.host_since = row[ 'host_since' ]
#   a.host_response_rate = row[ 'host_response_rate' ]
#   a.street = row[ 'street' ]
#   a.city = row[ 'city' ]
#   a.state = row[ 'state' ]
#   a.zipcode = row[ 'zipcode' ]
#   a.latitude = row[ 'latitude' ]
#   a.longitude = row[ 'longitude' ]
#   a.property_type = row[ 'property_type' ]
#   a.accommodates = row[ 'accommodates' ]
#   a.bathrooms = row[ 'bathrooms' ]
#   a.bedrooms = row[ 'bedrooms' ]
#   a.beds = row[ 'beds' ]
#   a.amenities = row[ 'amenities' ]
#   a.price = row[ 'price' ]
#   a.minimum_nights = row[ 'minimum_nights' ]
#   a.maximun_nights = row[ 'maximum_nights' ]
#   a.requires_license = row[ 'requires_license' ]
#   a.instant_bookable = row[ 'instant_bookable' ]
#   a.require_guest_profile_picture = row[ 'require_guest_profile_picture' ]
#   a.require_guest_phone_verification = row[ 'cancellation_policy' ]
#   a.reviews_per_month = row[ 'reviews_per_month' ]
  
#   a.save
#   puts Airbnb.find(a.id).airbnb_id
# end